"""Test configuration settings"""

SQL_TEST_CONFIG = {
    "url": "postgresql://test:test@localhost:5432/test_db",
    "echo": False
}

TYPEDB_TEST_CONFIG = {
    "url": "localhost:1729",
    "database": "test_db"
} 
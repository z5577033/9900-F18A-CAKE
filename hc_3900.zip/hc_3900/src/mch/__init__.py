"""

MCH package for methylation analysis
"""

__version__ = "0.1.0"

# Make commonly used components easily accessible
from mch.config.base_config import FREEZE, FREEZE_NUMBER, WORKING_DIRECTORY
